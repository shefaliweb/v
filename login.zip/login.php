
<?php

include("includes/config.php");

if(isset($_POST['submit'])){
$username=$_POST['username'];
$email=$_POST['email'];
$password=md5($_POST['password']);
$phone_number=$_POST['phone_number'];
$country=$_POST['country'];

   $query="SELECT * FROM `user` WHERE `email`='$email'";
    $result=mysqli_query($connection,$query);
    
   // echo $query;
    if (mysqli_num_rows($result)>0) {

       echo '<script type="text/javascript">'; 
       echo 'alert("Email id already exist");'; 
       echo 'window.location.href = "login.php";';
       echo '</script>';
   }else{

$query="INSERT INTO `user` (`id`, `username`, `email`, `password`, `phone_number`, `country`) VALUES (NULL, '$username', '$email', '$password', '$phone_number', '$country')";
if(mysqli_query($connection,$query)){

       echo '<script type="text/javascript">'; 
       echo 'alert("You are successfully register");'; 
       echo 'window.location.href = "login.php";';
       echo '</script>';
}
else{
      
        echo '<script type="text/javascript">'; 
        echo 'alert("Not register something went wrong");'; 
        echo 'window.location.href = "login.php";';
        echo '</script>';
// echo "<script>alert('Not register something went wrong');</script>";
}
}
}
if(isset($_POST['click'])) {
    $email=$_POST['email'];
    $password=md5($_POST['password']);
   
    $query="SELECT * FROM `user` WHERE `email`='$email'AND `password`='$password'";
    $result=mysqli_query($connection,$query);
    
   // echo $query;
    if (mysqli_num_rows($result)>0) {

       echo '<script type="text/javascript">'; 
       echo 'alert("Login successfully");'; 
       echo 'window.location.href = "index.php";';
       echo '</script>';
   }
   }     
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Login/Sign up</title>

	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- master stylesheet -->
	<link rel="stylesheet" href="css/style.css">
	<!-- Responsive stylesheet -->
	<link rel="stylesheet" href="css/responsive.css">

    <!-- Fixing Internet Explorer-->
    <!--[if lt IE 9]>
        <script src="http://php5shiv.googlecode.com/svn/trunk/php5.js"></script>
        <script src="js/php5shiv.js"></script>
    <![endif]-->
 <script type="text/javascript">
    function Validate() {
        var password = document.getElementById("txtPassword").value;
        var confirmPassword = document.getElementById("txtConfirmPassword").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
</script>

</head>
<body>
  <section class="top-bar-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-9">
                    <!--Start contact info left-->
                    <div class="contact-info-left clearfix">
                        <ul>

                            <li><span class="flaticon-new-email-outline envelop"></span>contact@visba.com</li>
                            <li><span class="flaticon-technology"></span>0591 2493015,   <span class="fa fa-whatsapp"></span>  +91-7037993744</li>
                        </ul>
                    </div>
                    <!--End contact info left-->
                </div>
                <div class="col-lg-4 col-md-5">
                    <!--Start contact info right-->
                    <div class="contact-info-right pull-right">

                        <div class="contact-info-left clearfix">
                            <ul>

                                <li><a href="login.php">Login/Sign Up</a></li>
                                <!-- <span class="fa fa-heart carticon" aria-hidden="true"></span>-->
                            </ul>
                        </div>
                    </div>
                    <!--End contact info right-->
                </div>
            </div>
        </div>
    </section>

    <!--Start header-search  area-->
    <section class="header-search">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="search-form pull-right">
                        <form action="#">
                            <div class="search">
                                <input type="search" name="search" value="" placeholder="Search Something">
                                <button type="submit"><span class="icon fa fa-search"></span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End header-search  area-->

    <!--Start header area-->
    <header class="header-area stricky">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="outer-box clearfix">
                        <!--Start logo-->
                         <div class="logo">
                            <a href="index.php" class="hvr-wobble-horizontal">
                                <img src="images/resources/logo.png" alt="Awesome Logo">
                            </a>
                        </div>
                        <!--End logo-->
                        <!--Start search box btn-->
                        <div class="search-box-btn">
                            <div class="toggle-search">
                                <button><span class="icon fa fa-search"></span></button>
                            </div>
                        </div>
                        <!--End search box btn-->
                        <!--Start cart btn-->
                        <div class="cart-btn">
                            <a href="wishlist.php">
                                <span class="fa fa-heart carticon" aria-hidden="true"></span>
                                <span class="item-count">2</span>
                            </a>
                        </div>
                        <!--End cart btn-->
                        <!--Start mainmenu-->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li class="current"><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About Us</a></li>



                                    <li class="dropdown"><a href="#">Product Category</a>
                                        <ul>
                                            <li class="dropdown"><a href="#">outdoor</a>
                                                <ul>
                                                    <li><a href="allproduct.php">Planters</a></li>
                                                    <li><a href="allproduct.php">Garden décor</a></li>
                                                    <li><a href="allproduct.php">Animals </a></li>
                                                    <li><a href="allproduct.php">Trays</a></li>
                                                    <li><a href="allproduct.php">Caddy</a></li>
                                                    <li><a href="allproduct.php">Watering</a></li>
                                                </ul>
                                            </li>
                                            <li class="dropdown"><a href="#">Kitchen</a>
                                                <ul>
                                                    <li><a href="allproduct.php">Storage Boxes</a></li>
                                                    <li><a href="allproduct.php">Trays</a></li>
                                                    <li><a href="allproduct.php">Bowls</a></li>
                                                    <li><a href="allproduct.php">Serving items</a></li>
                                                    <li><a href="allproduct.php">Champagne Bowls & Buckets</a></li>
                                                    <li><a href="allproduct.php">Ice Buckets</a></li>
                                                    <li><a href="allproduct.php">Bottle Stands</a></li>
                                                </ul>
                                            </li>
                                            <li class="dropdown"><a href="#">Decor</a>
                                                <ul>
                                                    <li><a href="allproduct.php">Lanterns </a></li>
                                                    <li><a href="allproduct.php">T-Lights</a></li>
                                                    <li><a href="allproduct.php">Candle Stands</a></li>
                                                    <li><a href="allproduct.php">Vases</a></li>
                                                    <li><a href="allproduct.php">Baskets</a></li>
                                                    <li><a href="allproduct.php">Mirrors</a></li>
                                                    <li><a href="allproduct.php">Decorative objects</a></li>
                                                </ul>
                                            </li>
                                            <li class="dropdown"><a href="#">Chirstmas</a>
                                                <ul>
                                                    <li><a href="allproduct.php">Reindeers</a></li>
                                                    <li><a href="allproduct.php">Hearts & Stars</a></li>
                                                    <li><a href="allproduct.php">Xmas Trees</a></li>
                                                    <li><a href="allproduct.php">Candle Stands</a></li>
                                                    <li><a href="allproduct.php">Candelabras  </a></li>
                                                    <li><a href="allproduct.php">Trays</a></li>
                                                </ul>
                                            </li>
                                            <li class="dropdown"><a href="#">Table Top</a>
                                                <ul>
                                                    <li><a href="allproduct.php">Dinner Plates & Bowl</a></li>
                                                    <li><a href="allproduct.php">Buffet & Charger Plate</a></li>
                                                    <li><a href="allproduct.php">Coffee & Tea Mugs</a></li>
                                                    <li><a href="allproduct.php">Napkin Holders</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                   <li><a href="fair-events.php"> Fair & Events</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </nav>
                        <!--End mainmenu-->
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--End header area-->

<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(images/breadcrumb/breadcrumb-bg.jpg);">
	<div class="container-fluid text-center">
		<h1>Login/Sign up</h1>
		<div class="breadcrumb-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="left pull-left">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                                <li><a href="shop.php">Shop</a></li>
                                <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                                <li>Login/Sign up</li>
                            </ul>    
                        </div>
                        <div class="right pull-right">
                            <a href="#"><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>Get a Quote</a>
                        </div>    
                    </div>
                </div>
            </div>
		</div>
	</div>
</section>
<!--End breadcrumb area-->
 
<!--Start account area-->
<section class="account-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12">
                <div class="form login-form">
                    <div class="sec-title-two">
                        <h3>Login Now</h3>
                    </div>
                    <form action="login.php" method="post">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="field-label">Email ID</div>
                                <div class="field-input">
                                    <input type="text" name="email" placeholder="Email Address"  required>
                                    <div class="icon-holder">
                                        <span class="flaticon-user-silhouette"></span>    
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="field-label">Password</div>
                                <div class="field-input">
                                    <input  pattern=".{5,10}" required title="5 to 10 characters" class="password" type="password" name="password" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;" required>
                                    <div class="icon-holder">
                                        <span class="flaticon-lock-padlock-symbol-for-protect"></span>    
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="remember-me pull-left">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="checkbox"  required><span>Remember me</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="forgot-password pull-right">
                                    <a href="#">Forgot Password?</a>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <button class="thm-btn bg-cl-1" type="submit" name="click" >Login now</button>    
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-8 col-md-7 col-sm-12 col-xs-12">
                <div class="form register">
                    <div class="sec-title-two">
                        <h3>Register Here</h3>
                    </div>
                    <form action="login.php" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="field-label">Name</div>
                                <div class="field-input">
                                    <input type="text" name="username" placeholder="" required>
                                    <div class="icon-holder">
                                        <span class="flaticon-user-silhouette"></span>    
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="field-label">Email Address</div>
                                <div class="field-input">
                                    <input type="text" name="email" placeholder="" required>
                                    <div class="icon-holder">
                                        <span class="flaticon-e-mail-envelope"></span>    
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="field-label">Password</div>
                                <div class="field-input">
                                    <input pattern=".{5,10}" required title="5 to 10 characters" for="password" type="password" name="password" placeholder="" id="txtPassword" required>
                                    <div class="icon-holder">
                                        <span class="flaticon-lock-padlock-symbol-for-protect"></span>    
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="field-label">Confirm Password</div>
                                <div class="field-input">
                                    <input pattern=".{5,10}" required title="5 to 10 characters" for="confirmpassword" type="password" name="confirm_password"   placeholder="" id="txtConfirmPassword" required>
                                    <div class="icon-holder">
                                        <span class="flaticon-lock-padlock-symbol-for-protect"></span>    
                                    </div>
                                </div>
                            </div> 
                            <div class="col-md-6">
                                <div class="field-label">Phone Number</div>
                                <div class="field-input">
                                    <input type="text" name="phone_number" placeholder="" required>
                                    <div class="icon-holder">
                                        <span class="flaticon-technology"></span>    
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="field-label">Country</div>
                                <div class="field-input">
                                    <input type="text" name="country" placeholder="" required>
                                    <div class="icon-holder">
                                        <span class="flaticon-map-marker-point"></span>    
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="term-condition">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="condition" required>
                                            <span>I agree the term’s & conditions</span>
                                        </label>
                                    </div>  
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <button  onclick="return Validate()" class="thm-btn bg-cl-1" type="submit" name="submit" >Register Here</button>
                            </div>       
                        </div>
                    </form>    
                </div>       
            </div>  
        </div> 
    </div>
</section>         
<!--End account area-->
                  
   <!--Start footer area-->
 <footer class="footer-area">
        <div class="container">
            <div class="row">
                <!--Start single footer widget-->
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="single-footer-widget pd-bottom">
                        <div class="footer-logo">
                            <a href="index.php" class="hvr-wobble-horizontal">
                                <img src="images/footer/footer-logo.png" alt="Awesome Footer Logo">
                            </a>
                        </div>
                        <div class="interrio-info">
                            <p><span>Visba</span> has been at the helm of manufacturing and exporting handicraft goods since 1982, established by the company’s founder Abdul Azim. </p>
                            <p>Visba initially started as a small trading company operating from a mere two-room office but it was not long before the company saw a change in its fortune. <a herf="about.php" style="color: #d5ac63; font-weight: bold;">Read More...</a></p>
                        </div>

                    </div>
                </div>
                <!--End single footer widget-->
                <!--Start single footer widget-->
                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="single-footer-widget pd-bottom">
                            <div class="title">
                                <h3>Useful Link</h3>
                            </div>
                            <ul class="popular-news clearfix">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="fair-events.php">Fair & Events</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="single-footer-widget pd-bottom">
                            <div class="title">
                                <h3>Our Category</h3>
                            </div>
                            <ul class="popular-news clearfix">
                                <li><a href="subcategory.php">Kitchen</a></li>
                                <li><a href="subcategory.php">About Us</a></li>
                                <li><a href="subcategory.php">Decor</a></li>
                                <li><a href="subcategory.php">Chirstmas</a></li>
                                <li><a href="subcategory.php">Table Top</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->
                <!--Start single footer widget-->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="single-footer-widget pd-bottom">
                        <div class="title">
                            <h3>Contact Info</h3>
                        </div>
                        <div class="single-footer-widget pd-bottom">
                            <ul class="footer-contact-info">
                                <li>
                                    <div class="icon-holder">
                                        <span class="flaticon-building"></span>
                                    </div>
                                    <div class="text-holder">
                                        <p>Head Office: W-111, Greater Kailash-2, New Delhi - 110048 India</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon-holder">
                                        <span class="flaticon-technology"></span>
                                    </div>
                                    <div class="text-holder">
                                        <p>0591 2493015, +91-7037993744</p>
                                    </div>
                                </li>
                                 <li>
                                    <div class="icon-holder">
                                        <span class="fa fa-whatsapp"></span>
                                    </div>
                                    <div class="text-holder">
                                        <p>+91-7037993744</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon-holder">
                                        <span class="flaticon-e-mail-envelope"></span>
                                    </div>
                                    <div class="text-holder">
                                        <p>contact@visba.com</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon-holder time">
                                        <span class="flaticon-internet"></span>
                                    </div>
                                    <div class="text-holder">
                                        <p>
                                            www.visba.com
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->
            </div>
        </div>
    </footer>
    <!--End footer area-->

    <!--Start footer bottom area-->
    <section class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <div class="copyright-text">
                        <p>© 2020 Visba ,  All Rights Reserved </p>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            <!--<li><a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a></li>-->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End footer bottom area-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="php"><span class="fa fa-angle-up"></span></div>

<!-- main jQuery -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- bx slider -->
<script src="js/jquery.bxslider.min.js"></script>
<!-- count to -->
<script src="js/jquery.countTo.js"></script>
<!-- owl carousel -->
<script src="js/owl.carousel.min.js"></script>
<!-- validate -->
<script src="js/validate.js"></script>
<!-- mixit up -->
<script src="js/jquery.mixitup.min.js"></script>
<!-- easing -->
<script src="js/jquery.easing.min.js"></script>
<!-- gmap helper -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAHzPSV2jshbjI8fqnC_C4L08ffnj5EN3A"></script>
<!--gmap script-->
<script src="js/gmaps.js"></script>
<script src="js/map-helper-2.js"></script>
<!-- video responsive script -->
<script src="js/jquery.fitvids.js"></script>
<!-- jQuery ui js -->
<script src="assets/jquery-ui-1.11.4/jquery-ui.js"></script>
<!-- Language Switche  -->
<script src="assets/language-switcher/jquery.polyglot.language.switcher.js"></script>
<!-- fancy box -->
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.appear.js"></script>
<!-- isotope script-->
<script src="js/isotope.js"></script>
<!-- Pretty photo script-->
<script src="js/jquery.prettyPhoto.js"></script>
<!-- Bootstrap Touchspin -->
<script src="js/jquery.bootstrap-touchspin.js"></script>                    
		
<!-- revolution slider js -->
<script src="assets/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>



<!-- thm custom script -->
<script src="js/custom.js"></script>






</body>

<!-- Mirrored from st.ourphpdemo.com/new/interrio/account.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 17 Oct 2020 08:04:17 GMT -->
</html>